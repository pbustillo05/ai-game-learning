"""Host orchestration analysis, not a GPU or production throughput benchmark."""
from collections import Counter, deque
import hashlib
import json
from pathlib import Path

source = Path('pbg/core/training.py').read_text()
assert 'first = ready[0]' in source
assert 'lanes[index] != lanes[cohort[-1]] + 1' in source


def packets(pre, total=256):
    result = []
    for family, rows, cap in [('pre', pre, 32), ('post_2', total-pre, 8)]:
        for begin in range(0, rows, cap):
            result.append((family, min(cap, rows-begin), begin))
    return result


def simulate(proposed):
    queues = [deque(packets(97+lane)) for lane in range(16)]
    consumed = [[] for _ in queues]
    calls = []
    while any(queues):
        ready = [lane for lane, queue in enumerate(queues) if queue]
        if proposed:
            # Proposed bounded scheduling: retain every lane's FIFO, flush the
            # earliest pending family, then use the largest contiguous cohort.
            rank = min(0 if queues[lane][0][0] == 'pre' else 1 for lane in ready)
            eligible = [lane for lane in ready
                        if (0 if queues[lane][0][0] == 'pre' else 1) == rank]
            groups = []
            for lane in eligible:
                key = queues[lane][0][:2]
                if groups and lane == groups[-1][-1]+1 and queues[groups[-1][0]][0][:2] == key:
                    groups[-1].append(lane)
                else:
                    groups.append([lane])
            cohort = max(groups, key=lambda lanes: (len(lanes), -lanes[0]))
        else:
            first = ready[0]
            key = queues[first][0][:2]
            cohort = [first]
            for lane in ready[1:]:
                if lane != cohort[-1]+1 or queues[lane][0][:2] != key:
                    break
                cohort.append(lane)
        family, rows, _ = queues[cohort[0]][0]
        calls.append((family, len(cohort), rows))
        for lane in cohort:
            consumed[lane].append(queues[lane].popleft())
    assert consumed == [packets(97+lane) for lane in range(16)]
    assert all(sum(item[1] for item in lane) == 256 for lane in consumed)
    return {
        'cohort_calls': len(calls),
        'calls_by_family': dict(Counter(family for family, _, _ in calls)),
        'cohort_width_histogram': dict(Counter(width for _, width, _ in calls)),
        'post_cohort_width_histogram': dict(Counter(width for family, width, _ in calls if family == 'post_2')),
        'per_lane_fifo_and_total_rows_preserved': True,
    }


report = {
    'scope': 'Synthetic host orchestration analysis; no CUDA state, model operations, losses, or measured runtime',
    'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'source': 'pbg/core/training.py:optimize_prepared',
    'assumptions': {'replicas': 16, 'logical_steps': 1, 'rows_per_lane': 256,
                    'pre_rows_by_lane': list(range(97, 113)), 'physical_caps': {'pre': 32, 'post_2': 8},
                    'compatible_batched_operation': True, 'families_in_fifo_order': ['pre', 'post_2']},
    'current_lowest_lane_selection': simulate(False),
    'proposed_family_priority_and_largest_contiguous_cohort': simulate(True),
    'interpretation': 'Demonstrates structural cohort fragmentation in this fixture. Call-count reduction is not a speedup estimate. Validate on real prepared samplers, gradients, RNG, ragged actions, and full-pipeline timing before changing production.',
}
target = Path(__file__).with_suffix('.json')
target.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
