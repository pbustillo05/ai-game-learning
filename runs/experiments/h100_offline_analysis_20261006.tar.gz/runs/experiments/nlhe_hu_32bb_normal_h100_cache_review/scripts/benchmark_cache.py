"""Explicit experimental variants of the sole public CUDA training pipeline."""
import argparse
import hashlib
import json
import os
import subprocess
import threading
import time
from dataclasses import asdict
from pathlib import Path

import torch
import yaml

import pbg.core.precision as precision
from pbg.benchmark import benchmark_training
from pbg.config import load_config_mapping
from pbg.h100_pilot import Arm, benchmark_summary, h100_preflight, pilot_config_mapping


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--replicas', type=int, default=1)
    parser.add_argument('--mode', choices=['normal', 'rb'], default='normal')
    parser.add_argument('--stage', choices=['smoke', 'production'], default='production')
    parser.add_argument('--program', choices=['eager', 'compiled', 'captured'], default='eager')
    parser.add_argument('--fp32-matmul', choices=['ieee', 'tf32'], default='ieee')
    parser.add_argument('--seed', type=int, default=104830)
    parser.add_argument('--warmup', type=int, default=2)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--learner-pack', type=int, default=32)
    parser.add_argument('--post-pack', type=int, default=8)
    parser.add_argument('--reference-cache-bytes', type=int, default=0)
    parser.add_argument('--phase-telemetry', action='store_true')
    parser.add_argument('--directory', required=True)
    args = parser.parse_args()
    directory = Path(args.directory)
    directory.mkdir(parents=True, exist_ok=True)
    production = args.stage == 'production'
    hardware = h100_preflight()
    name = f'nlhe_hu_32bb_{args.mode}_h100_{args.stage}_k{args.replicas}_{args.program}_{args.fp32_matmul}'
    arm = Arm(name, 'replica_scaling' if production else 'smoke', args.mode, args.replicas,
              64 if production else 4, (256 if production else 16) if args.mode == 'rb' else None,
              rollout_pack=8 if production else 2, completion_pack=64 if production else 4,
              learner_pack=args.learner_pack if production else 2,
              warmup=args.warmup, repeats=args.repeats, seed=args.seed)
    raw = pilot_config_mapping(arm, output_dir=directory / 'runtime')
    raw['run']['execution']['tensor_program']['mode'] = args.program
    raw['run']['execution']['reference_cache'] = ({'budget_bytes': args.reference_cache_bytes}
        if args.reference_cache_bytes else 'off')
    if production:
        raw['run']['execution']['microbatch']['learner_rows']['post_2'] = args.post_pack
    config_path = Path('configs/experiments') / directory.name / f'{name}.yaml'
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(yaml.safe_dump(raw, sort_keys=False))
    original_policy = precision.configure_cuda_reproducibility

    def experiment_policy(profile):
        result = original_policy(profile)
        torch.backends.cuda.matmul.fp32_precision = args.fp32_matmul
        result['matmul_fp32_precision'] = args.fp32_matmul
        return result

    # Experimental override recorded in actual runtime/benchmark backend identity;
    # production source and default policy are unchanged.
    precision.configure_cuda_reproducibility = experiment_policy
    competing_jobs = []
    stop_watchdog = threading.Event()
    def watch_ownership():
        selector = hardware['idle_before']['selector']
        while not stop_watchdog.is_set():
            try:
                observed = subprocess.check_output(['nvidia-smi', '--id='+selector,
                    '--query-compute-apps=pid,used_memory', '--format=csv,noheader'], text=True).strip()
            except Exception as exc:
                competing_jobs.append({'utc':time.time(),'ownership_error':str(exc)})
                return
            other = [row for row in observed.splitlines()
                     if row.strip() and int(row.split(',')[0]) != os.getpid()]
            if other: competing_jobs.append({'utc':time.time(),'jobs':other})
            stop_watchdog.wait(1.0)
    watchdog = threading.Thread(target=watch_ownership, daemon=True)
    watchdog.start()
    monitor_path = directory / 'nvml.csv'
    with monitor_path.open('w') as monitor_output:
        monitor = subprocess.Popen(['nvidia-smi', '--query-gpu=timestamp,uuid,utilization.gpu,utilization.memory,memory.used,power.draw,clocks.sm,clocks.mem', '--format=csv', '--loop-ms=1000'], stdout=monitor_output)
        try:
            benchmark = benchmark_training(load_config_mapping(raw), warmup=args.warmup,
                repeats=args.repeats, progress_path=directory / 'progress.json',
                phase_telemetry=args.phase_telemetry)
        finally:
            monitor.terminate()
            monitor.wait()
            stop_watchdog.set()
            watchdog.join(timeout=10)
    report = {'isolation':{'timing_valid':not competing_jobs,'competing_jobs':competing_jobs,
                           'ownership_check_period_seconds':1.0}, 'scope': 'Full public training pipeline; production preserves batch=256, steps=116. Experimental execution/FP32 precision variants are explicit.',
              'hardware_preflight': hardware, 'arm': asdict(arm), 'arguments': vars(args),
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'compiler_environment': {key: os.environ.get(key) for key in ('TORCHINDUCTOR_MAX_AUTOTUNE_GEMM_BACKENDS','TORCHINDUCTOR_COMPILE_THREADS')},
              'config_sha256': hashlib.sha256(config_path.read_bytes()).hexdigest(),
              'summary': benchmark_summary(arm, benchmark), 'benchmark': benchmark}
    (directory / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report['summary']), flush=True)
    if competing_jobs: raise RuntimeError('Competing GPU job detected; timings are invalid. See report isolation evidence.')


if __name__ == '__main__':
    main()
