"""Isolated native model probes; timing and profiler evidence stay separate."""
import argparse
import copy
import hashlib
import json
import os
import statistics
import subprocess
import time
from collections import defaultdict
from pathlib import Path

import torch
from torch.nn.attention import SDPBackend, sdpa_kernel

from pbg.core.execution_program import TensorProgramRunner
from pbg.core.precision import configure_cuda_reproducibility
from pbg.core.replica import ReplicaModuleOwner
from pbg.games.poker.queued.hooks import NLHEGeometry, PokerStateMachine
from pbg.games.poker.queued.model import build_model_from_config
from pbg.h100_pilot import Arm, pilot_config_mapping
from pbg.identity import code_identity


def summarize_trace(path):
    events = json.loads(path.read_text())["traceEvents"]
    bounds = next(event for event in events if event.get("name") == "measured_model_probe")
    start, end = bounds["ts"], bounds["ts"] + bounds["dur"]
    kernels = [event for event in events if event.get("cat") == "kernel" and event.get("ph") == "X"]
    intervals = sorted((max(start, event["ts"]), min(end, event["ts"] + event["dur"]))
                       for event in events if event.get("cat") in ("kernel", "gpu_memcpy", "gpu_memset")
                       and event.get("ph") == "X" and event["ts"] < end and event["ts"] + event["dur"] > start)
    merged = []
    for left, right in intervals:
        if merged and left <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], right)
        else:
            merged.append([left, right])
    busy = sum(right - left for left, right in merged)
    gaps = [right[0] - left[1] for left, right in zip(merged, merged[1:])]
    grouped = defaultdict(lambda: {"calls": 0, "duration_us": 0.0})
    for event in kernels:
        row = grouped[event["name"]]
        row["calls"] += 1
        row["duration_us"] += event["dur"]
        row.setdefault("launch_metadata", event.get("args", {}))
    return {"profiled_cpu_range_us": end - start, "gpu_active_union_us": busy,
            "gpu_temporal_busy_fraction": busy / (end - start),
            "kernel_count": len(kernels), "largest_between_activity_gap_us": max(gaps, default=0),
            "top_kernels": sorted((dict(name=name, **row) for name, row in grouped.items()),
                                  key=lambda row: row["duration_us"], reverse=True)[:25],
            "interpretation": "Temporal activity from CUPTI trace, not spatial SM/Tensor Core occupancy. Profile overhead included."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replicas", type=int, default=1)
    parser.add_argument("--family", choices=["pre", "post_2"], default="pre")
    parser.add_argument("--rows", type=int, default=2)
    parser.add_argument("--mode", choices=["eager", "compiled", "captured"], default="eager")
    parser.add_argument("--repeats", type=int, default=7)
    parser.add_argument("--selected", action="store_true")
    parser.add_argument("--sequential", action="store_true")
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--fp32-matmul", choices=["ieee", "tf32"], default="ieee")
    parser.add_argument("--sdpa-backend", choices=["auto", "flash", "cudnn"], default="auto")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.replicas < 1 or args.rows < 1 or args.repeats < 1:
        parser.error("positive replicas, rows and repeats required")
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(4)
    backend_policy = configure_cuda_reproducibility("throughput")
    torch.backends.cuda.matmul.fp32_precision = args.fp32_matmul
    backend_policy["matmul_fp32_precision"] = args.fp32_matmul
    if args.sdpa_backend != "auto":
        import pbg.games.poker.model.primitives as primitives
        backend = {"flash": SDPBackend.FLASH_ATTENTION, "cudnn": SDPBackend.CUDNN_ATTENTION}[args.sdpa_backend]
        primitives.sdpa_kernel = lambda backends: sdpa_kernel([backend])
    torch.manual_seed(104830)
    scientific = pilot_config_mapping(Arm("probe", "smoke", "normal", 1, 1, None), output_dir="/tmp/unused")["scientific"]
    source = build_model_from_config(scientific, "cuda:0")
    owner = ReplicaModuleOwner([copy.deepcopy(source) for _ in range(args.replicas)])
    del source
    machine = PokerStateMachine(NLHEGeometry(2, 32, 13))
    state = machine.initial_roots(args.rows, seed=104830, iteration=0, retry_epoch=0, device="cuda:0")
    if args.family != "pre":
        state.street.fill_(1)
        state.board_cards[:, :3] = torch.tensor([0, 5, 10], dtype=torch.uint8, device="cuda")
    inputs = machine.direct_model_input(args.family, state).to(torch.bfloat16)
    selected = torch.zeros(args.rows, device="cuda", dtype=torch.int64)
    if args.family != "pre":
        _, mask = owner.lane_module(0)._public(state, machine.empty_history(args.rows, "cuda:0"))
        selected = mask.to(torch.int64).argmax(1)
    modules = ([owner.cohort_module(lane, 1) for lane in range(args.replicas)] if args.sequential
               else [owner.cohort_module(0, args.replicas)])
    programs = []
    lanes_per_call = 1 if args.sequential else args.replicas
    chosen = selected.repeat(lanes_per_call) if args.selected else None
    for module in modules:
        def program(value, scale, module=module):
            with torch.autocast("cuda", dtype=torch.bfloat16):
                result = module.forward_partition(args.family, value, chosen)
                loss = result.value.float().square().sum() * scale
            return result.value.detach(), loss
        programs.append(program)
    runners = [TensorProgramRunner(mode=args.mode, byte_budget=8 << 30, reserve_bytes=10 << 30) for _ in modules]
    value = inputs.repeat(lanes_per_call, 1)
    scale = torch.tensor(1 / (args.rows * lanes_per_call), device="cuda")

    def invoke():
        owner.gradients.zero_()
        for runner, program in zip(runners, programs):
            runner.run(args.family, program, (value, scale), mutable=(owner.gradients,))

    warmup_started = time.perf_counter()
    for _ in range(3):
        invoke()
    torch.cuda.synchronize()
    warmup_seconds = time.perf_counter() - warmup_started
    before = [runner.manifest() for runner in runners]
    times = []
    torch.cuda.reset_peak_memory_stats()
    monitoring_path = output_path.with_suffix(".nvml.csv")
    with monitoring_path.open("w") as monitoring_output:
        monitor = subprocess.Popen(["nvidia-smi", "--query-gpu=timestamp,uuid,utilization.gpu,utilization.memory,memory.used,power.draw,clocks.sm,clocks.mem", "--format=csv", "--loop-ms=100"], stdout=monitoring_output)
        try:
            for _ in range(args.repeats):
                torch.cuda.synchronize()
                started = time.perf_counter()
                invoke()
                torch.cuda.synchronize()
                times.append(time.perf_counter() - started)
        finally:
            monitor.terminate()
            monitor.wait()
    report = {"schema": "h100-native-model-probe-v2", "scope": "Model forward/backward value objective only; excludes rollout, PPO loss, reference, Adam, scheduler. Isolated unprofiled timing.",
              "arguments": vars(args), "code": code_identity(), "cuda_backend_policy": backend_policy,
              "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "compiler_environment": {key: os.environ.get(key) for key in ("TORCHINDUCTOR_MAX_AUTOTUNE_GEMM_BACKENDS", "TORCHINDUCTOR_COMPILE_THREADS")},
              "gpu": torch.cuda.get_device_name(), "torch": torch.__version__, "cuda": torch.version.cuda,
              "seconds": times, "median_seconds": statistics.median(times), "warmup_seconds": warmup_seconds,
              "presentations_per_second": args.replicas * args.rows / statistics.median(times),
              "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
              "parameters_per_replica": owner.parameter_count, "program_before": before,
              "program_after": [runner.manifest() for runner in runners], "gradients_finite": bool(torch.isfinite(owner.gradients).all())}
    if args.profile:
        trace_path = output_path.with_suffix(".trace.json")
        with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA]) as profiler:
            with torch.profiler.record_function("measured_model_probe"):
                invoke()
                torch.cuda.synchronize()
        profiler.export_chrome_trace(str(trace_path))
        report["profile"] = summarize_trace(trace_path)
    output_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in ("median_seconds", "presentations_per_second", "peak_allocated_bytes", "gradients_finite")}))


if __name__ == "__main__":
    main()
