"""CUDA oracle: full-model BF16 norm rounding versus current production."""
import copy
import json
import os
from pathlib import Path
import pytest
import torch
from pbg.core import tensor_ops
from pbg.core.replica import ReplicaModuleOwner
from pbg.games.poker.queued.hooks import NLHEGeometry, PokerStateMachine
from pbg.games.poker.queued.model import build_model_from_config
from pbg.h100_pilot import Arm, pilot_config_mapping


@pytest.mark.parametrize("family", ("pre", "post_2"))
@pytest.mark.parametrize("replicas", (1, 2))
def test_full_model_rounding_and_gradient_contract(family, replicas, monkeypatch):
    assert torch.cuda.is_available(), "CUDA required"
    candidate = tensor_ops.LayerNorm.forward
    original = getattr(candidate, "original_forward", None)
    assert original is not None, "Run with h100_lowp_norm_candidate.py --target tests"
    torch.manual_seed(104830)
    scientific = pilot_config_mapping(Arm("oracle", "smoke", "normal", 1, 1, None),
                                      output_dir="/tmp/unused")["scientific"]
    source = build_model_from_config(scientific, "cuda:0")
    owner = ReplicaModuleOwner([copy.deepcopy(source) for _ in range(replicas)])
    del source
    module = owner.cohort_module(0, replicas)
    machine = PokerStateMachine(NLHEGeometry(2, 32, 13))
    state = machine.initial_roots(2, seed=104830, iteration=0, retry_epoch=0, device="cuda:0")
    if family == "post_2":
        state.street.fill_(1)
        state.board_cards[:, :3] = torch.tensor([0, 5, 10], dtype=torch.uint8, device="cuda")
    value = machine.direct_model_input(family, state).to(torch.bfloat16).repeat(replicas, 1)
    pointers = tuple(p.grad.data_ptr() for p in module.parameters())

    def evaluate(forward):
        monkeypatch.setattr(tensor_ops.LayerNorm, "forward", forward)
        owner.gradients.zero_()
        with torch.autocast("cuda", dtype=torch.bfloat16):
            result = module.forward_natural_partition(family, value)
            fields = {"value": result.value, **result.policy_raw}
            loss = sum(v.float().square().mean() for v in fields.values())
        loss.backward()
        outputs = {name: v.detach().float().clone() for name, v in fields.items()}
        return outputs, owner.gradients.clone(), loss.detach().float()

    expected, gradients, baseline_loss = evaluate(original)
    actual, candidate_gradients, candidate_loss = evaluate(candidate)
    assert tuple(p.grad.data_ptr() for p in module.parameters()) == pointers
    owner.assert_zero_copy()
    assert bool(torch.isfinite(candidate_gradients).all())
    measurements = {}
    for name in expected:
        assert actual[name].shape == expected[name].shape
        assert bool(torch.isfinite(actual[name]).all())
        relative_l2 = (actual[name] - expected[name]).norm() / expected[name].norm().clamp_min(1e-12)
        measurements[name] = dict(relative_l2=float(relative_l2),
                                  maximum_absolute=float((actual[name] - expected[name]).abs().max()))
        assert float(relative_l2) < .03, (name, measurements[name])
    grad_error = (candidate_gradients - gradients).norm() / gradients.norm().clamp_min(1e-12)
    grad_cosine = torch.nn.functional.cosine_similarity(candidate_gradients.flatten(),
                                                       gradients.flatten(), dim=0)
    assert float(grad_error) < .03
    assert float(grad_cosine) > .995
    report = dict(family=family, replicas=replicas, outputs=measurements,
                  gradient_relative_l2=float(grad_error), gradient_cosine=float(grad_cosine),
                  baseline_loss=float(baseline_loss), candidate_loss=float(candidate_loss),
                  scope="Full native six-layer R13 model output/gradient rounding and storage oracle; not learning-quality evidence")
    path = Path(os.environ["H100_NORM_ORACLE_REPORT"])
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as out: out.write(json.dumps(report) + "\n")
