"""Untimed IEEE/TF32 short-training comparisons, not a learning-quality claim."""
import json
import math
from pathlib import Path

import torch
import pbg.core.precision as precision
from pbg.config import load_config_mapping
from pbg.h100_pilot import Arm, pilot_config_mapping
from pbg.identity import code_identity
from pbg.runtime import TrainingSession

torch.set_num_threads(4)
base = Path('/workspace/ai-game-learning/runs/experiments/nlhe_hu_32bb_normal_h100_validation')
original = precision.configure_cuda_reproducibility
results = []
for seed in (104830, 205991):
    for mode in ('normal', 'rb'):
        reference_initial = reference_final = None
        for candidate in ('ieee', 'tf32'):
            def policy(profile, candidate=candidate):
                value = original(profile)
                torch.backends.cuda.matmul.fp32_precision = candidate
                value['matmul_fp32_precision'] = candidate
                return value
            precision.configure_cuda_reproducibility = policy
            raw = pilot_config_mapping(Arm('stability', 'smoke', mode, 2, 4,
                16 if mode == 'rb' else None, rollout_pack=4, completion_pack=4, learner_pack=4,
                seed=seed), output_dir=base / 'runtime' / f'{mode}_{candidate}_{seed}')
            raw['run']['execution']['tensor_program']['mode'] = 'eager'
            raw['run']['execution']['tensor_program']['cache_bytes'] = 0
            session = TrainingSession(load_config_mapping(raw))
            try:
                initial = session.modules.master.detach().clone()
                if candidate == 'ieee': reference_initial = initial.clone()
                else: assert torch.equal(initial, reference_initial)
                samples = []
                for iteration in range(3):
                    value = session.step()
                    assert bool(torch.isfinite(session.modules.master).all())
                    assert bool(torch.isfinite(session.modules.gradients).all())
                    lane_metrics = []
                    for lane in value.results:
                        assert all(step.applied and step.gradients_finite for step in lane.learner.optimizer_steps)
                        assert all(math.isfinite(number) for loss in lane.learner.losses for number in loss.values())
                        lane_metrics.append({'player_nodes': lane.player_nodes,
                            'losses': lane.learner.losses,
                            'gradient_norms': [step.grad_norm for step in lane.learner.optimizer_steps]})
                    samples.append({'iteration': iteration + 1, 'lanes': lane_metrics})
                    del value
                final = session.modules.master.detach().clone()
                row = {'mode': mode, 'seed': seed, 'fp32_matmul': candidate,
                    'backend_policy': session.backend_policy, 'iterations': samples,
                    'parameter_update_l2': float(torch.linalg.vector_norm(final - initial)),
                    'finite_parameters_gradients_losses': True}
                if candidate == 'ieee': reference_final = final.clone()
                else:
                    delta, baseline_delta = final - initial, reference_final - reference_initial
                    row.update({'model_difference_l2': float(torch.linalg.vector_norm(final - reference_final)),
                        'relative_update_difference_l2': float(torch.linalg.vector_norm(delta - baseline_delta) / torch.linalg.vector_norm(baseline_delta)),
                        'update_cosine_similarity': float(torch.nn.functional.cosine_similarity(delta.reshape(1,-1), baseline_delta.reshape(1,-1)))})
                results.append(row)
                print(json.dumps({key: row[key] for key in row if key != 'iterations'}), flush=True)
                del initial, final
            finally:
                session.close()
            torch.cuda.empty_cache()
        del reference_initial, reference_final
report = {'scope': 'Concurrent untimed three-iteration native BF16 stability, two seeds, Normal/RB. No long-run learning-quality or isolated speed claim.',
          'code': code_identity(), 'results': results}
(base / 'reports/tf32_training_stability.json').write_text(json.dumps(report,indent=2)+'\n')
