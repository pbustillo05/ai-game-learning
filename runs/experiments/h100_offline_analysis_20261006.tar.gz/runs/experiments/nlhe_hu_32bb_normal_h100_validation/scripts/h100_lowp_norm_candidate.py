"""Experimental model-only normalization output dtype; queue/reduction storage unchanged."""
import argparse,hashlib,importlib.util,json,sys
from pathlib import Path
import torch
import pbg.core.tensor_ops as tensor_ops

parser=argparse.ArgumentParser();parser.add_argument('--target',choices=['model','tests'],required=True)
parser.add_argument('--report',required=True);args,rest=parser.parse_known_args()
original=tensor_ops.LayerNorm.forward
calls={}
def candidate(self,value):
    enabled=torch.is_autocast_enabled(value.device.type)
    dtype=torch.get_autocast_dtype(value.device.type) if enabled else value.dtype
    if value.device.type=='cuda' and enabled and dtype==torch.bfloat16:
        # Native low-precision layer_norm still accumulates statistics in FP32.
        with torch.autocast('cuda',enabled=False):
            return original(self,value.to(dtype))
    return original(self,value)
tensor_ops.LayerNorm.forward=candidate
out=Path(args.report);out.parent.mkdir(parents=True,exist_ok=True)
try:
    if args.target=='model':
        script=Path(__file__).with_name('h100_model_benchmark.py')
        spec=importlib.util.spec_from_file_location('h100_model_probe',script)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        sys.argv=[str(script),*rest];module.main()
        report={'status':'complete','scope':'Experimental BF16 layer_norm working output, FP32 statistics/master/optimizer/reach/loss retained','wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    else:
        import pytest
        code=pytest.main(rest)
        report={'status':'complete' if code==0 else 'failed','pytest_exit_code':code,'scope':'Same CUDA gates with BF16 norm candidate; no tolerance changes','wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    out.write_text(json.dumps(report,indent=2)+'\n')
    if args.target=='tests':sys.exit(code)
finally:
    tensor_ops.LayerNorm.forward=original
