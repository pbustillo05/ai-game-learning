import argparse,json
from collections import defaultdict
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('directory');args=p.parse_args();root=Path(args.directory)
windows=[json.loads(l) for l in (root/'phase_windows.jsonl').read_text().splitlines()]
rows=[json.loads(l) for l in (root/'gpm.jsonl').read_text().splitlines() if json.loads(l).get('type')=='sample']
previous=None;intervals=[]
for row in rows:
 if previous is not None and 'metrics' in row:intervals.append((previous['utc_epoch'],row['utc_epoch'],row))
 previous=row
last={}
for window in windows:last[window['phase']]=window
report=json.loads((root/'report.json').read_text());result={'scope':'Last instrumented iteration only; GPM intervals wholly contained in phase, duration-weighted. Telemetry synchronization overhead applies; phases shorter than interval have no counter attribution.','iteration_seconds':report['summary']['seconds'],'phases':{}}
for name,window in last.items():
 start,end=window['start_utc_epoch'],window['end_utc_epoch'];covered=0;totals=defaultdict(float);weights=defaultdict(float);count=0
 for a,b,row in intervals:
  if a>=start and b<=end:
   count+=1;covered+=b-a
   for key,metric in row['metrics'].items():
    if metric.get('value') is not None:totals[key]+=metric['value']*(b-a);weights[key]+=b-a
 result['phases'][name]={'wall_seconds':end-start,'whole_interval_count':count,'covered_seconds':covered,'mean_gpm_pct':{k:v/weights[k] for k,v in totals.items()}}
(root/'phase_gpm_summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
