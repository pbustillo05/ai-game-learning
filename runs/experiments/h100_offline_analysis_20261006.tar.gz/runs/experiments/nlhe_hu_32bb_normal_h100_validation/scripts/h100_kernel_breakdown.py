"""CUPTI kernel time accounting with host operator correlation; no GPU required."""
import argparse
from collections import defaultdict
import json
from pathlib import Path


def summarize(path):
    events = json.loads(Path(path).read_text())['traceEvents']
    hosts = {e.get('args', {}).get('External id'): e for e in events if e.get('cat') == 'cpu_op'}
    kernels = [e for e in events if e.get('cat') == 'kernel' and e.get('ph') == 'X']
    categories = defaultdict(lambda: {'calls': 0, 'duration_us': 0.})
    grouped = defaultdict(lambda: {'calls': 0, 'duration_us': 0., 'host_ops': set()})
    matrix_ops = {'aten::mm', 'aten::bmm', 'aten::addmm', 'aten::baddbmm', 'aten::_scaled_mm'}
    for event in kernels:
        name = event['name'].lower()
        host = hosts.get(event.get('args', {}).get('External id'), {})
        op = host.get('name', '')
        if 'sdpa' in name or 'fmha' in name or 'cudnn::fusion' in name or 'attention' in name:
            category = 'attention'
        elif op in matrix_ops or any(word in name for word in ('gemm', 'cutlass', 'cublas', 'nvjet')):
            category = 'matrix_multiplication'
        elif 'layer_norm' in name or 'layernorm' in name:
            category = 'normalization'
        elif 'copy_kernel' in name or 'direct_copy' in name or 'catarray' in name or op in {'aten::copy_', 'aten::_to_copy', 'aten::cat'}:
            category = 'copy_cast_concatenation'
        elif 'reduce' in name or 'reduction' in name:
            category = 'reductions'
        elif 'elementwise' in name or 'vectorized' in name or 'unrolled' in name:
            category = 'elementwise'
        else:
            category = 'other'
        row = categories[category]
        row['calls'] += 1
        row['duration_us'] += event['dur']
        row = grouped[event['name']]
        row['calls'] += 1
        row['duration_us'] += event['dur']
        row['host_ops'].add(op)
        row.setdefault('launch', event.get('args', {}))
        row.setdefault('host_input_shapes', host.get('args', {}).get('Input Dims'))
        row.setdefault('host_input_types', host.get('args', {}).get('Input type'))
    total = sum(row['duration_us'] for row in categories.values())
    for row in categories.values():
        row['summed_kernel_time_pct'] = row['duration_us'] / total * 100 if total else None
    intervals = sorted((e['ts'], e['ts'] + e['dur']) for e in kernels)
    union = []
    for start, end in intervals:
        if union and start <= union[-1][1]:
            union[-1][1] = max(union[-1][1], end)
        else:
            union.append([start, end])
    top = []
    for name, row in sorted(grouped.items(), key=lambda item: item[1]['duration_us'], reverse=True):
        row = dict(row, name=name, host_ops=sorted(row['host_ops']))
        top.append(row)
    return dict(trace=str(path), scope='Profiled kernel-duration accounting; overhead applies. Summed kernel times may overlap. Kernel categories use host-op correlation plus names. Matrix/attention kernel duration is not Tensor Core instruction-active time or peak FLOPs utilization.',
                kernel_count=len(kernels), summed_kernel_us=total,
                gpu_activity_union_us=sum(b-a for a,b in union),
                first_to_last_kernel_us=union[-1][1]-union[0][0] if union else 0,
                categories=dict(categories), top_kernels=top[:40])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('traces', nargs='+')
    args = parser.parse_args()
    for trace in args.traces:
        result = summarize(trace)
        Path(trace).with_suffix('.breakdown.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({k: result[k] for k in ('trace', 'kernel_count', 'summed_kernel_us', 'categories')}, indent=2))
