"""Experimental BF16 working-feature padding; original parameters/queues unchanged."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import sys
import torch
import torch.nn.functional as F
import pbg.core.tensor_ops as tensor_ops

parser = argparse.ArgumentParser()
parser.add_argument('--target', choices=['model', 'tests'], required=True)
parser.add_argument('--report', required=True)
args, rest = parser.parse_known_args()
original = tensor_ops.linear


def candidate(value, weight, bias=None):
    if (value.device.type == 'cuda' and torch.is_autocast_enabled('cuda')
            and torch.get_autocast_dtype('cuda') == torch.bfloat16
            and weight.shape[-2:] == (512, 343)):
        # Add one exact-zero feature and one exact-zero working weight column.
        # Neither is a parameter. Autograd crops their gradients back to 343.
        value = F.pad(value.to(torch.bfloat16), (0, 1))
        weight = F.pad(weight.to(torch.bfloat16), (0, 1))
    return original(value, weight, bias)


tensor_ops.linear = candidate
out = Path(args.report)
out.parent.mkdir(parents=True, exist_ok=True)
try:
    if args.target == 'model':
        script = Path(__file__).with_name('h100_model_benchmark.py')
        sys.argv = [str(script), *rest]
        runpy.run_path(str(script), run_name='__main__')
        import pytest
        code = pytest.main(['-q', str(Path(__file__).with_name('test_alignment_candidate.py'))])
    else:
        import pytest
        code = pytest.main(rest)
    out.write_text(json.dumps(dict(status='complete' if code == 0 else 'failed',
        exit_code=code, scope='Experimental post FFN 343->344 BF16 working-feature/weight padding only; original parameter layout, gradients, queues, private-hand IDs and mathematical projection unchanged.',
        wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()), indent=2) + '\n')
    sys.exit(code)
finally:
    tensor_ops.linear = original
