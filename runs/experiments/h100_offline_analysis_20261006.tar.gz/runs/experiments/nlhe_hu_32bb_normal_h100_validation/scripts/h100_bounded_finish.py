"""Exclusive, deadline-bounded final measurements; no production code changes."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import time

ROOT = Path('/workspace/ai-game-learning')
BASE = ROOT / 'runs/experiments/nlhe_hu_32bb_normal_h100_validation'
REPORTS = BASE / 'reports'
STATE = REPORTS / 'bounded_final_status.json'
DEADLINE = dt.datetime(2026, 10, 7, 0, 1, 48, tzinfo=dt.timezone.utc).timestamp()
CUTOFF = DEADLINE - 120  # reserve teardown and offline archive time
TRAIN = BASE / 'scripts/h100_training_benchmark.py'
GPU = os.environ['CUDA_VISIBLE_DEVICES']
REV = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
SHA = hashlib.sha256(TRAIN.read_bytes()).hexdigest()
STATE_DATA = dict(pid=os.getpid(), source_revision=REV, script_sha256=SHA,
                  hard_deadline_utc='2026-10-07T00:01:48Z', completed=[], failed=[], deferred=[])
boundary_path = os.environ.get('H100_BOUNDARY_FILE')
if boundary_path and STATE.exists():
    previous = json.loads(STATE.read_text())
    STATE_DATA.update({key: previous[key] for key in ('completed', 'failed', 'deferred')})
STOP = False


def record(**values):
    STATE_DATA.update(values, updated_utc=dt.datetime.now(dt.timezone.utc).isoformat())
    temporary = STATE.with_suffix('.tmp')
    temporary.write_text(json.dumps(STATE_DATA, indent=2) + '\n')
    temporary.replace(STATE)


def proc(pid):
    try:
        content = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        return dict(state=content[0], parent=int(content[1]), start=content[19])
    except (FileNotFoundError, ProcessLookupError):
        return None


def descendants(parent):
    found = {parent: proc(parent)}
    processes = {int(p.name): proc(int(p.name)) for p in Path('/proc').iterdir() if p.name.isdigit()}
    changed = True
    while changed:
        changed = False
        for pid, detail in processes.items():
            if detail and detail['parent'] in found and pid not in found:
                found[pid] = detail
                changed = True
    return {p: d for p, d in found.items() if d}


def terminate_tree(pid, process_group=False):
    owned = descendants(pid)
    for sig in (signal.SIGTERM, signal.SIGKILL):
        if process_group:
            try:
                os.killpg(pid, sig)
            except ProcessLookupError:
                pass
        else:
            for child, expected in reversed(list(owned.items())):
                current = proc(child)
                if current and current['start'] == expected['start'] and current['state'] != 'Z':
                    try:
                        os.kill(child, sig)
                    except ProcessLookupError:
                        pass
        if sig == signal.SIGTERM:
            time.sleep(5)


def owners():
    return subprocess.check_output(['nvidia-smi', '--id=' + GPU,
        '--query-compute-apps=pid,used_memory', '--format=csv,noheader'], text=True).strip()


def idle():
    for _ in range(30):
        if not owners():
            return True
        time.sleep(.2)
    return False


def result_valid(directory):
    path = directory / 'report.json'
    if not path.exists():
        return False
    data = json.loads(path.read_text())
    if data.get('schema') == 'h100-native-model-probe-v2':
        return data['code']['git_revision'] == REV and data['gradients_finite']
    return (data['isolation']['timing_valid'] and data['isolation']['source_consistent']
            and data['benchmark']['identity']['code']['git_revision'] == REV
            and data['script_sha256'] == SHA)


def failed_cleanup(directory):
    # Retain logs, progress and telemetry, remove only this arm's failed runtime/config.
    import shutil
    for path in (directory / 'runtime', ROOT / 'configs/experiments' / directory.name):
        if path.exists():
            shutil.rmtree(path)


def on_signal(signum, frame):
    global STOP
    STOP = True


signal.signal(signal.SIGINT, on_signal)
signal.signal(signal.SIGTERM, on_signal)
os.chdir(ROOT)
record(status='adopting_existing_capture')

# The old scheduler was stopped before starting this controller. It must never launch again.
old_queue = 139432
old_capture = 143376
boundary = json.loads(Path(boundary_path).read_text()) if boundary_path else None
if boundary:
    old_queue, old_capture = boundary['parent_pid'], boundary['child_pid']
if proc(old_queue):
    command = Path(f'/proc/{old_queue}/cmdline').read_bytes()
    assert (b'h100_bounded_finish.py' if boundary else b'/tmp/h100_final_stage_queue.py') in command
    assert proc(old_queue)['state'] == 'T'
else:
    assert boundary, 'Original scheduler unexpectedly missing'
capture_start = proc(old_capture)
adopted = ROOT / 'runs/experiments/nlhe_hu_32bb_normal_h100_captured_k2_p2_q2_s104830_8236a61_smoke'
capture_limit = min(CUTOFF, dt.datetime(2026, 10, 6, 23, 15, 31, tzinfo=dt.timezone.utc).timestamp())
if boundary:
    adopted = Path(boundary['directory'])
    capture_limit = min(CUTOFF, boundary['stage_deadline_epoch'])
while capture_start:
    current = proc(old_capture)
    if not current or current['start'] != capture_start['start'] or current['state'] == 'Z':
        break
    record(stage=adopted.name, status='waiting_for_existing_capture')
    if STOP or time.time() >= capture_limit:
        terminate_tree(old_capture)
        break
    time.sleep(2)
if boundary and proc(old_queue):
    # The previous controller has a SIGTERM handler. At an idle child boundary,
    # kill only that verified stopped orchestration process to prevent double scheduling.
    os.kill(old_queue, signal.SIGKILL)
elif not boundary:
    os.kill(old_queue, signal.SIGTERM)
    os.kill(old_queue, signal.SIGCONT)
time.sleep(1)
observer = 132421
try:
    if b'/tmp/h100_queue_observer.py' in Path(f'/proc/{observer}/cmdline').read_bytes():
        os.kill(observer, signal.SIGTERM)
except FileNotFoundError:
    pass
if result_valid(adopted):
    STATE_DATA['completed'].append(adopted.name)
else:
    STATE_DATA['failed'].append(dict(stage=adopted.name, reason='No valid report within capture timebox; not a proven code defect.'))
    failed_cleanup(adopted)
assert idle(), 'GPU not idle after adopted capture; refusing additional jobs'

arms = []

# User priority: explain low Tensor Core activity using actual full-size learner calls.
profile_directory = ROOT / 'runs/experiments/nlhe_hu_32bb_normal_h100_learner_profile_actual_8236a61'
profile_command = [sys.executable, str(BASE / 'scripts/h100_profile_learner.py'),
    '--replicas', '1', '--mode', 'normal', '--stage', 'production', '--program', 'eager',
    '--learner-pack', '256', '--post-pack', '128', '--reference-cache-bytes', str(1 << 30),
    '--warmup', '1', '--repeats', '1', '--directory', str(profile_directory)]
arms.append((profile_directory, profile_command, 300, 120))

for k, rows in ((1, 80), (16, 8)):
    for candidate in (False, True):
        label = 'padded344' if candidate else 'baseline343'
        directory = ROOT / 'runs/experiments' / f'nlhe_hu_32bb_normal_h100_model_post_k{k}_r{rows}_{label}_8236a61'
        command = [sys.executable]
        if candidate:
            command += [str(BASE / 'scripts/h100_alignment_candidate.py'), '--target', 'model',
                        '--report', str(directory / 'candidate.json')]
        else:
            command += [str(BASE / 'scripts/h100_model_benchmark.py')]
        command += ['--replicas', str(k), '--family', 'post_2', '--rows', str(rows), '--mode', 'eager',
                    '--profile', '--output', str(directory / 'report.json')]
        arms.append((directory, command, 180, 60))


def add(mode, k, pre, post, *, seed=104830, cache=0, batch=None, steps=None,
        stage='production', program='eager', warmup=1, repeats=3, limit=360, minimum=120):
    name = f'nlhe_hu_32bb_{mode}_h100_{program}_k{k}_p{pre}_q{post}_s{seed}_{REV[:7]}'
    if stage == 'smoke':
        name += '_smoke'
    if cache:
        name += '_cache'
    if batch:
        name += f'_b{batch}'
    directory = ROOT / 'runs/experiments' / name
    command = [sys.executable, str(TRAIN), '--replicas', str(k), '--mode', mode,
               '--stage', stage, '--program', program, '--learner-pack', str(pre),
               '--post-pack', str(post), '--seed', str(seed), '--warmup', str(warmup),
               '--repeats', str(repeats), '--directory', str(directory)]
    if cache:
        command.extend(['--reference-cache-bytes', str(cache)])
    if batch:
        command.extend(['--batch-size', str(batch), '--steps', str(steps)])
    arms.append((directory, command, limit, minimum))


# Prioritize quick, interpretable tuning and independent-seed checks before cold compilation.
# Synchronous diagnostics for the newly observed K=2 capture illegal-address failure.
debug_directory = ROOT / 'runs/experiments/nlhe_hu_32bb_normal_h100_captured_k2_debug_8236a61'
debug_command = [sys.executable, str(TRAIN), '--replicas', '2', '--mode', 'normal',
    '--stage', 'smoke', '--program', 'captured', '--learner-pack', '2', '--post-pack', '2',
    '--warmup', '0', '--repeats', '1', '--directory', str(debug_directory)]
if adopted != debug_directory:
    arms.append((debug_directory, debug_command, 900, 300))
add('normal', 1, 512, 256, cache=1 << 30, batch=512, steps=58, limit=360)
add('normal', 1, 256, 128, seed=205991, cache=1 << 30, limit=300)
add('rb', 1, 256, 128, seed=205991, cache=1 << 30, limit=300)
# Additional RB captures are deferred while the asynchronous K=2 illegal
# access remains unexplained. Preserve time for the user's kernel investigation.
STATE_DATA['deferred'].extend([dict(stage=f'RB_K{k}_captured_smoke',
    reason='Prioritize Tensor Core investigation and unexplained asynchronous capture failure') for k in (1, 2)])
add('normal', 16, 32, 8, repeats=2, limit=900, minimum=300)
env = dict(os.environ, TORCHINDUCTOR_MAX_AUTOTUNE_GEMM_BACKENDS='ATEN', TORCHINDUCTOR_COMPILE_THREADS='4')
Path('/tmp/h100_gpu_reservation.json').write_text(json.dumps(dict(
    owner='bounded_final_tmux', controller_pid=os.getpid(), status='exclusive_final_series',
    state=str(STATE), deadline_utc='2026-10-07T00:01:48Z'), indent=2) + '\n')
for directory, command, limit, minimum in arms:
    remaining = CUTOFF - time.time()
    if STOP or remaining < minimum:
        STATE_DATA['deferred'].append(dict(stage=directory.name, reason='Wall-clock budget'))
        continue
    if result_valid(directory):
        STATE_DATA['completed'].append(directory.name)
        continue
    assert idle(), 'GPU occupied; refusing to interfere with other owners'
    assert hashlib.sha256(TRAIN.read_bytes()).hexdigest() == SHA
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == REV
    end = min(CUTOFF, time.time() + limit)
    record(status='running', stage=directory.name, command=command,
           stage_deadline_utc=dt.datetime.fromtimestamp(end, dt.timezone.utc).isoformat())
    with (REPORTS / f'{directory.name}.bounded.log').open('w') as log:
        stage_env = dict(env, CUDA_LAUNCH_BLOCKING='1') if directory == debug_directory else env
        child = subprocess.Popen(command, env=stage_env, stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=True)
        timed_out = False
        while child.poll() is None:
            if STOP or time.time() >= end:
                terminate_tree(child.pid, process_group=True)
                timed_out = True
                break
            time.sleep(2)
        child.wait()
    if child.returncode == 0 and result_valid(directory):
        STATE_DATA['completed'].append(directory.name)
    else:
        STATE_DATA['failed'].append(dict(stage=directory.name, returncode=child.returncode,
            reason='Timebox expired; incomplete evidence' if timed_out else 'Execution/report validation failure',
            log=str(REPORTS / f'{directory.name}.bounded.log')))
        failed_cleanup(directory)
    assert idle(), 'GPU teardown incomplete; stopping series'
    record(status='between_stages')

record(status='finished', stage=None, final_gpu_owners=owners())
assert not STATE_DATA['final_gpu_owners'], 'Final GPU ownership not empty'
subprocess.run(['nvidia-smi', '--id=' + GPU], stdout=(REPORTS / 'bounded_final_gpu.txt').open('w'), check=True)
for cmd, name in ((['git', 'show', '--stat', 'HEAD'], 'bounded_source_identity.txt'),
                  (['git', 'diff'], 'bounded_worktree.diff')):
    (REPORTS / name).write_text(subprocess.check_output(cmd, text=True))
archive = ROOT / 'runs/experiments/h100_offline_analysis_20261006.tar.gz'
with tarfile.open(archive, 'w:gz') as output:
    for path in (ROOT / 'docs/audit').glob('*h100*20261006.md'):
        output.add(path, arcname=str(path.relative_to(ROOT)))
    for directory in (ROOT / 'runs/experiments').glob('*h100*'):
        if not directory.is_dir():
            continue
        for path in directory.rglob('*'):
            if path.is_file() and 'runtime' not in path.relative_to(directory).parts and path.suffix in ('.json', '.jsonl', '.log', '.csv', '.txt', '.py', '.md', '.diff'):
                output.add(path, arcname=str(path.relative_to(ROOT)))
    for path in (ROOT / 'configs/experiments').rglob('*.yaml'):
        if 'h100' in str(path):
            output.add(path, arcname=str(path.relative_to(ROOT)))
    for path in (ROOT / 'tools/h100-gpm-monitor.py', ROOT / 'pbg/h100_pilot.py'):
        output.add(path, arcname=str(path.relative_to(ROOT)))
record(status='finished', offline_archive=str(archive), archive_bytes=archive.stat().st_size)
print(json.dumps(STATE_DATA, indent=2), flush=True)
