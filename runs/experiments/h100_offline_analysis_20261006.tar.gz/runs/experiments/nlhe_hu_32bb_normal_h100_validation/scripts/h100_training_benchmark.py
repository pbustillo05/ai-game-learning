"""Explicit experimental variants of the sole public CUDA training pipeline."""
import argparse
import hashlib
import json
import os
import subprocess
import threading
import time
import sys
from dataclasses import asdict
from pathlib import Path

import torch
import yaml

import pbg.core.precision as precision
from pbg.benchmark import benchmark_training
from pbg.config import load_config_mapping
from pbg.h100_pilot import Arm, benchmark_summary, h100_preflight, pilot_config_mapping


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--replicas', type=int, default=1)
    parser.add_argument('--mode', choices=['normal', 'rb'], default='normal')
    parser.add_argument('--stage', choices=['smoke', 'production'], default='production')
    parser.add_argument('--program', choices=['eager', 'compiled', 'captured'], default='eager')
    parser.add_argument('--fp32-matmul', choices=['ieee', 'tf32'], default='ieee')
    parser.add_argument('--seed', type=int, default=104830)
    parser.add_argument('--warmup', type=int, default=2)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--learner-pack', type=int, default=32)
    parser.add_argument('--post-pack', type=int, default=8)
    parser.add_argument('--reference-cache-bytes', type=int, default=0)
    parser.add_argument('--batch-size', type=int)
    parser.add_argument('--steps', type=int)
    parser.add_argument('--phase-telemetry', action='store_true')
    parser.add_argument('--directory', required=True)
    args = parser.parse_args()
    if (args.batch_size is None) != (args.steps is None):
        parser.error('batch-size and steps must be supplied together for schedule tuning')
    if args.batch_size is not None and (args.batch_size <= 0 or args.steps <= 0 or args.stage != 'production'):
        parser.error('schedule tuning requires positive values and production stage')
    directory = Path(args.directory)
    directory.mkdir(parents=True, exist_ok=True)
    production = args.stage == 'production'
    hardware = h100_preflight()
    name = f'nlhe_hu_32bb_{args.mode}_h100_{args.stage}_k{args.replicas}_{args.program}_{args.fp32_matmul}'
    arm = Arm(name, 'replica_scaling' if production else 'smoke', args.mode, args.replicas,
              64 if production else 4, (256 if production else 16) if args.mode == 'rb' else None,
              rollout_pack=8 if production else 2, completion_pack=64 if production else 4,
              learner_pack=args.learner_pack if production else 2,
              warmup=args.warmup, repeats=args.repeats, seed=args.seed)
    raw = pilot_config_mapping(arm, output_dir=directory / 'runtime')
    if args.batch_size is not None:
        raw['scientific']['schedule'] = {'batch_size':args.batch_size, 'steps':args.steps}
    raw['run']['execution']['tensor_program']['mode'] = args.program
    raw['run']['execution']['reference_cache'] = ({'budget_bytes':args.reference_cache_bytes}
        if args.reference_cache_bytes else 'off')
    if production:
        raw['run']['execution']['microbatch']['learner_rows']['pre'] = args.learner_pack
        raw['run']['execution']['microbatch']['learner_rows']['post_2'] = args.post_pack
    config_path = Path('configs/experiments') / directory.name / f'{name}.yaml'
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(yaml.safe_dump(raw, sort_keys=False))
    if args.phase_telemetry:
        from pbg.core.capacity import GeneratedOwners
        original_enter = GeneratedOwners.enter_phase
        original_release = GeneratedOwners.release_after
        phase_started = {}
        phase_log = (directory/'phase_windows.jsonl').open('w')
        def enter_phase(owners, phase):
            phase_started[(id(owners), phase.name)] = time.time()
            return original_enter(owners, phase)
        def release_after(owners, phase):
            start = phase_started.pop((id(owners), phase.name), None)
            if start is not None:
                phase_log.write(json.dumps({'phase':phase.name,'start_utc_epoch':start,
                    'end_utc_epoch':time.time(),'owners_id':id(owners)})+'\n')
                phase_log.flush()
            return original_release(owners, phase)
        GeneratedOwners.enter_phase = enter_phase
        GeneratedOwners.release_after = release_after
    original_policy = precision.configure_cuda_reproducibility

    def experiment_policy(profile):
        result = original_policy(profile)
        torch.backends.cuda.matmul.fp32_precision = args.fp32_matmul
        result['matmul_fp32_precision'] = args.fp32_matmul
        return result

    # Experimental override recorded in actual runtime/benchmark backend identity;
    # production source and default policy are unchanged.
    precision.configure_cuda_reproducibility = experiment_policy
    competing_jobs = []
    stop_watchdog = threading.Event()
    def watch_ownership():
        selector = hardware['idle_before']['selector']
        while not stop_watchdog.is_set():
            try:
                observed = subprocess.check_output(['nvidia-smi', '--id='+selector,
                    '--query-compute-apps=pid,used_memory', '--format=csv,noheader'], text=True).strip()
            except Exception as exc:
                competing_jobs.append({'utc':time.time(),'ownership_error':str(exc)})
                return
            other = [row for row in observed.splitlines()
                     if row.strip() and int(row.split(',')[0]) != os.getpid()]
            if other: competing_jobs.append({'utc':time.time(),'jobs':other})
            stop_watchdog.wait(1.0)
    watchdog = threading.Thread(target=watch_ownership, daemon=True)
    watchdog.start()
    gpm = subprocess.Popen([sys.executable, 'tools/h100-gpm-monitor.py',
        '--uuid', hardware['idle_before']['selector'], '--output',str(directory/'gpm.jsonl')])
    monitor_path = directory / 'nvml.csv'
    with monitor_path.open('w') as monitor_output:
        monitor = subprocess.Popen(['nvidia-smi', '--query-gpu=timestamp,uuid,utilization.gpu,utilization.memory,memory.used,power.draw,clocks.sm,clocks.mem', '--format=csv', '--loop-ms=1000'], stdout=monitor_output)
        try:
            benchmark = benchmark_training(load_config_mapping(raw), warmup=args.warmup,
                repeats=args.repeats, progress_path=directory / 'progress.json',
                phase_telemetry=args.phase_telemetry)
        finally:
            gpm.terminate()
            gpm.wait(timeout=10)
            monitor.terminate()
            monitor.wait()
            stop_watchdog.set()
            watchdog.join(timeout=10)
    source_consistent = hardware['code'] == benchmark['identity']['code']
    summary = benchmark_summary(arm, benchmark)
    summary['batch_size'] = raw['scientific']['schedule']['batch_size']
    summary['steps_per_replica'] = raw['scientific']['schedule']['steps']
    report = {'isolation':{'timing_valid':not competing_jobs and source_consistent,
                           'source_consistent':source_consistent,'competing_jobs':competing_jobs,
                           'ownership_check_period_seconds':1.0}, 'gpm_monitor':{'interval_seconds':0.25,'exit_code':gpm.returncode,'path':str(directory/'gpm.jsonl')}, 'scope': 'Full public training pipeline; default production batch=256, steps=116. Optional schedule tuning changes optimizer work and is not a matched learning-quality comparison. Execution/precision/cache variants are explicit.',
              'hardware_preflight': hardware, 'arm': asdict(arm), 'arguments': vars(args),
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'compiler_environment': {key: os.environ.get(key) for key in ('TORCHINDUCTOR_MAX_AUTOTUNE_GEMM_BACKENDS','TORCHINDUCTOR_COMPILE_THREADS')},
              'config_sha256': hashlib.sha256(config_path.read_bytes()).hexdigest(),
              'summary': summary, 'benchmark': benchmark}
    (directory / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report['summary']), flush=True)
    if not source_consistent: raise RuntimeError('Source identity changed during benchmark; timing evidence rejected.')
    if competing_jobs: raise RuntimeError('Competing GPU job detected; timings are invalid. See report isolation evidence.')


if __name__ == '__main__':
    main()
