"""Isolated width/depth configuration ablation; no production/source changes."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

parser=argparse.ArgumentParser()
parser.add_argument("--layers",type=int,required=True)
parser.add_argument("--width",type=int,required=True)
parser.add_argument("--heads",type=int,required=True)
args,rest=parser.parse_known_args()
script=Path(__file__).with_name("h100_model_benchmark.py")
spec=importlib.util.spec_from_file_location("h100_architecture_model_probe",script)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=module.build_model_from_config
actual_scientific={}
def build(scientific,device):
    updated=copy.deepcopy(scientific)
    updated["model"].update(layers=args.layers,d_model=args.width,n_heads=args.heads)
    # Unspecified hidden retains existing adapter defaults. Shared trunk hidden
    # derives4d, so6x128 is exactly the original tested model.
    actual_scientific.update(updated)
    return original(updated,device)
module.build_model_from_config=build
sys.argv=[str(script),*rest]
module.main()
output=Path(rest[rest.index("--output")+1])
report=json.loads(output.read_text())
report["architecture_experiment"]=dict(layers=args.layers,width=args.width,
    heads=args.heads,shared_ffn_hidden=4*args.width,ffn_hidden_config=None,
    scientific=actual_scientific,
    wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    scope="Model-only width/depth ablation; preserve queues/full hand domains/I-O/shared trunk. Different weights/capacity; no learning-quality equivalence or whole-training speed claim.")
output.write_text(json.dumps(report,indent=2)+"\n")
