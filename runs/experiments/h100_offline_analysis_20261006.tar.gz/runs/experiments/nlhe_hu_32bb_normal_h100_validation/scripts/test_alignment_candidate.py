"""CUDA projection/gradient oracle for the experimental 343->344 working pad."""
import math
import pytest
import torch
from pbg.core import tensor_ops


@pytest.mark.parametrize('lanes', [1, 2, 4])
def test_projection_preserves_master_layout_and_lane_gradients(lanes):
    torch.manual_seed(937)
    count = 512 * 343
    master = torch.randn(lanes, count + 113, device='cuda') / math.sqrt(343)
    gradients = torch.zeros_like(master)
    weight = torch.nn.Parameter(master[:, 17:17+count].view(lanes, 512, 343))
    weight.grad = gradients[:, 17:17+count].view_as(weight)
    pointer, grad_pointer = weight.data_ptr(), weight.grad.data_ptr()
    value = torch.randn(lanes * 16, 343, device='cuda', dtype=torch.bfloat16, requires_grad=True)
    with torch.autocast('cuda', dtype=torch.bfloat16):
        result = tensor_ops.linear(value, weight)
        objective = result.float().square().sum() / 16
    objective.backward()
    for lane in range(lanes):
        reference_weight = weight[lane].detach().clone().requires_grad_()
        reference_input = value[lane*16:(lane+1)*16].detach().clone().requires_grad_()
        with torch.autocast('cuda', dtype=torch.bfloat16):
            expected = torch.nn.functional.linear(reference_input, reference_weight)
            loss = expected.float().square().sum() / 16
        loss.backward()
        torch.testing.assert_close(result[lane*16:(lane+1)*16], expected, rtol=3e-2, atol=3e-3)
        torch.testing.assert_close(weight.grad[lane], reference_weight.grad, rtol=3e-2, atol=3e-3)
        torch.testing.assert_close(value.grad[lane*16:(lane+1)*16], reference_input.grad, rtol=3e-2, atol=3e-3)
    assert pointer == weight.data_ptr() and grad_pointer == weight.grad.data_ptr()
    assert weight.shape == (lanes, 512, 343)
    assert torch.isfinite(gradients).all()
    assert gradients[:, :17].eq(0).all() and gradients[:, 17+count:].eq(0).all()
