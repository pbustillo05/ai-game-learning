"""Profile one actual full-size learner program per family, after an unprofiled warmup."""
import json
from pathlib import Path
import runpy
import sys
import os
import subprocess
import time
import torch

from pbg.core.execution_program import TensorProgramRunner
from pbg.runtime import TrainingSession

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from h100_kernel_breakdown import summarize

directory = Path(sys.argv[sys.argv.index('--directory') + 1])
directory.mkdir(parents=True, exist_ok=True)
original_step = TrainingSession.step
original_run = TensorProgramRunner.run
step_count = 0
profiled = set()


def step(self, *args, **kwargs):
    global step_count
    step_count += 1
    return original_step(self, *args, **kwargs)


def run(self, key, operation, inputs, *, mutable):
    family = key[0][1]
    rows = key[0][2]
    target = {'pre', 'post_2'}
    # A statistical batch splits across families; physical packs need not reach
    # the configured cap. Profile actual packets rather than assuming cap rows.
    if step_count < 2 or family not in target or family in profiled:
        return original_run(self, key, operation, inputs, mutable=mutable)
    profiled.add(family)
    torch.cuda.synchronize()
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                          torch.profiler.ProfilerActivity.CUDA],
                                record_shapes=True) as profiler:
        with torch.profiler.record_function('representative_learner_program'):
            result = original_run(self, key, operation, inputs, mutable=mutable)
            torch.cuda.synchronize()
    trace = directory / f'learner_{family}_rows{rows}.trace.json'
    profiler.export_chrome_trace(str(trace))
    breakdown = summarize(trace)
    breakdown.update(family=family, rows_per_lane=rows, lane_count=len(key[1]),
                     inputs=[dict(shape=list(v.shape), dtype=str(v.dtype)) for v in inputs])
    trace.with_suffix('.breakdown.json').write_text(json.dumps(breakdown, indent=2) + '\n')
    return result


TrainingSession.step = step
TensorProgramRunner.run = run
runpy.run_path(str(BASE / 'h100_training_benchmark.py'), run_name='__main__')
assert profiled == {'pre', 'post_2'}, f'Expected both full-pack families, got {profiled}'
path = directory / 'report.json'
report = json.loads(path.read_text())
report.update(scope='Profiled actual cached learner pre=256/post=128 programs. Full iteration includes profiler overhead; DO NOT use for throughput comparisons.',
              profiling=dict(families=sorted(profiled), warmup_unprofiled=True))
path.write_text(json.dumps(report, indent=2) + '\n')

# A bounded dense BF16 GEMM calibration checks whether GPM can report high
# Tensor Core activity on this same hardware. It is not a training benchmark.
gpm_path = directory / 'dense_bf16_gemm_gpm.jsonl'
monitor = subprocess.Popen([sys.executable, 'tools/h100-gpm-monitor.py',
    '--uuid', os.environ['CUDA_VISIBLE_DEVICES'], '--output', str(gpm_path)])
try:
    size = 8192
    a = torch.randn(size, size, device='cuda', dtype=torch.bfloat16)
    b = torch.randn_like(a)
    c = torch.empty_like(a)
    for _ in range(8):
        torch.mm(a, b, out=c)
    torch.cuda.synchronize()
    start = time.time()
    count = 0
    while time.time() - start < 8:
        for _ in range(10):
            torch.mm(a, b, out=c)
        torch.cuda.synchronize()
        count += 10
    end = time.time()
finally:
    monitor.terminate()
    monitor.wait(timeout=10)
samples = [json.loads(line) for line in gpm_path.read_text().splitlines()]
previous = None
total, weights = {}, {}
for row in samples:
    if row.get('type') != 'sample':
        continue
    if previous is not None and previous >= start and row['utc_epoch'] <= end:
        duration = row['utc_epoch'] - previous
        for name, metric in row.get('metrics', {}).items():
            if metric.get('value') is not None:
                total[name] = total.get(name, 0) + metric['value'] * duration
                weights[name] = weights.get(name, 0) + duration
    previous = row['utc_epoch']
calibration = dict(scope='Eight-second forward-only dense BF16 square GEMM calibration, not training throughput. Wall-clock includes bounded synchronization between batches of ten.',
    matrix_size=size, calls=count, wall_seconds=end-start,
    arithmetic_tflops_per_second=2 * size**3 * count / (end-start) / 1e12,
    mean_gpm_pct={name: value / weights[name] for name, value in total.items()})
(directory / 'dense_bf16_gemm_calibration.json').write_text(json.dumps(calibration, indent=2) + '\n')
