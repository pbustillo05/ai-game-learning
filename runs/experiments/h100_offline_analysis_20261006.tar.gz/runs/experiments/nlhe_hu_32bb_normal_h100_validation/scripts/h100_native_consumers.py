"""Untimed full-depth BF16 multiway/branched integration checks."""
import json
import math
import argparse
import ast
from pathlib import Path

import torch
import yaml

from pbg.config import load_config_mapping
from pbg.identity import code_identity
from pbg.runtime import TrainingSession

parser = argparse.ArgumentParser()
parser.add_argument('--candidate-capacity', action='store_true')
args = parser.parse_args()
if args.candidate_capacity:
    import pbg.config as config_module
    import pbg.games.poker.queued.capacity_compiler as compiler_module
    candidate = ast.parse(Path('/tmp/h100_capacity_compiler_candidate.py').read_text())
    function = next(node for node in candidate.body if isinstance(node, ast.FunctionDef) and node.name=='compile_capacity')
    exec(compile(ast.Module(body=[function],type_ignores=[]), '/tmp/h100_capacity_compiler_candidate.py','exec'), compiler_module.__dict__)
    config_module.compile_capacity = compiler_module.compile_capacity

torch.set_num_threads(4)
base = Path('/workspace/ai-game-learning/runs/experiments/nlhe_hu_32bb_normal_h100_validation')
evidence = []
for players in (2, 6):
    for rollout in ('sequential', 'branched.fixed', 'branched.KKT'):
        for estimator in ('sampled', 'rao_blackwell'):
            raw = yaml.safe_load(Path('configs/train/nlhe_hu_8bb_normal_smoke.yaml').read_text())
            if rollout != 'sequential':
                raw['scientific']['objective']['branching'] = {
                    'trace_coefficient':0.1,'cost_coefficient':0.1,'trace_epsilon':1.0e-6}
                raw['scientific']['branching'] = {'fixed_beta':{'player':1.5,'chance':1.25},
                    'beta_max':3,'minimum_tree_size':16,
                    'cost_safeguard':{'gamma_deviance_max':0.2,'p95_underprediction_max':1.5,
                                      'consecutive_iterations':4}}
                raw['run']['workload']['tree_nodes'] = 512
                raw['run']['recovery'] = {'minimum_branch_scale':0.25,'branch_backoff_factor':0.5}
                if rollout == 'branched.KKT':
                    raw['scientific']['branching']['kkt'] = {'warmup_iterations':1,
                        'target_tree_size':256.0,'gamma_kappa':0.2,'eta_kappa':0.2,
                        'kappa_min':0.25,'kappa_max':4.0,'log_kappa':0.0}
            raw['scientific']['mode'] = {'training_regime': 'self_play', 'rollout_mode': rollout,
                                         'private_estimator': estimator}
            raw['scientific']['game'] = {'players': players, 'stack_bb': 8.0, 'rank_count': 6}
            raw['scientific']['model'].update(d_model=128, n_heads=4, layers=6,
                class_embedding_dim=32, ffn_hidden=512, folder_beta_rank=16)
            raw['scientific']['schedule'] = {'batch_size': 8, 'steps': 2}
            if estimator == 'rao_blackwell': raw['scientific']['completion'] = {'samples': 8}
            raw['scientific']['objective']['reference_kl'] = {'coefficient': 0.05,
                                                            'refresh': {'effective_hands': 0.5}}
            raw['run']['reproducibility'] = 'throughput'
            raw['run']['workload'].update(roots=2, replicas=2)
            raw['run']['execution'] = {'device': 'cuda:0', 'precision': 'bf16', 'attention': 'sdpa',
                'reference_cache': 'off', 'tensor_program': {'mode':'eager','cache_entries':8,'cache_bytes':0},
                'memory': {'reserve_bytes': 10 << 30},
                'microbatch': {'rollout_rows': 2, 'completion_rows': 4,
                    'learner_rows': {'pre': 4, **{f'post_{live}':2 for live in range(2, players+1)}}}}
            variant = f'{players}p_{rollout}_{estimator}'
            kind = ('rb' if estimator=='rao_blackwell' else 'normal') if rollout=='sequential' else rollout.replace('.','_')
            name = f'nlhe_{"hu" if players==2 else "6max"}_8bb_{kind}_h100_native_{estimator}'
            raw['run']['output_dir'] = str(base/'runtime'/name)
            cfgpath = Path('configs/experiments')/'nlhe_hu_8bb_normal_h100_native_consumers'/f'{name}.yaml'
            cfgpath.parent.mkdir(parents=True,exist_ok=True)
            cfgpath.write_text(yaml.safe_dump(raw,sort_keys=False))
            print('Starting',variant,flush=True)
            session = TrainingSession(load_config_mapping(raw))
            iterations = []
            try:
                for iteration in range(3):
                    result = session.step()
                    assert bool(torch.isfinite(session.modules.master).all())
                    assert bool(torch.isfinite(session.modules.gradients).all())
                    session.modules.assert_zero_copy()
                    assert all(state.iteration == iteration+1 for state in session.run_states)
                    assert all(state.reference_iteration == iteration+1 for state in session.reference_states)
                    for lane in result.results:
                        assert all(step.applied and step.gradients_finite for step in lane.learner.optimizer_steps)
                        assert all(math.isfinite(v) for loss in lane.learner.losses for v in loss.values())
                    iterations.append({'iteration':iteration+1,'player_nodes':sum(v.player_nodes for v in result.results),
                        'peak_allocated_bytes':torch.cuda.max_memory_allocated(),
                        'logical_work':[dict(state.logical_work) for state in session.run_states],
                        'structure':[dict(v.observability) for v in result.results]})
                    print(variant,iteration+1,iterations[-1]['player_nodes'],flush=True)
                    del result
                evidence.append({'variant':variant,'full_depth_native_bf16':True,'iterations':iterations})
            finally:
                session.close()
            torch.cuda.empty_cache()
report={'scope':'Concurrent untimed native six-layer BF16, HU/6max reduced-deck consumers, reference refresh; not a timing claim.',
        'candidate_capacity':args.candidate_capacity,
        'code':code_identity(),'evidence':evidence}
(base/'reports/native_consumers.json').write_text(json.dumps(report,indent=2)+'\n')
