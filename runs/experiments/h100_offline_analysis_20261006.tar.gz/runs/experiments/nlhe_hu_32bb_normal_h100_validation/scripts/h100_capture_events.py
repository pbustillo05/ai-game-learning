"""Future CUDA diagnostic wrapper; this file has not been run on CUDA.

Adds host event records around the unchanged public training benchmark.
Default instrumentation never synchronizes CUDA. Optional synchronization
changes timing/ordering and cannot establish asynchronous correctness.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--event-log", required=True)
    parser.add_argument("--sync-after-program", action="store_true")
    parser.add_argument("--persistent-stream-candidate", action="store_true")
    parser.add_argument("benchmark_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    remaining = args.benchmark_args
    if remaining and remaining[0] == "--":
        remaining = remaining[1:]
    target = Path(__file__).with_name("h100_training_benchmark.py")
    path = Path(args.event_log)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", buffering=1) as output:
        def emit(event, **fields):
            output.write(json.dumps(dict(event=event, utc_epoch=time.time(),
                                         pid=os.getpid(), **fields)) + "\n")
        emit("identity", revision=subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True).strip(),
            wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            training_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
            sync_after_program=args.sync_after_program,
            persistent_stream_candidate=args.persistent_stream_candidate,
            candidate_revision="96a7654" if args.persistent_stream_candidate else None,
            CUDA_LAUNCH_BLOCKING=os.environ.get("CUDA_LAUNCH_BLOCKING"),
            benchmark_args=remaining)
        import torch
        import pbg.core.execution_program as program_module
        if args.persistent_stream_candidate:
            candidate = subprocess.check_output(
                ["git", "show", "96a7654:pbg/core/execution_program.py"], text=True)
            exec(compile(candidate, "<candidate96a7654>", "exec"), program_module.__dict__)
        TensorProgramRunner = program_module.TensorProgramRunner
        original_run = TensorProgramRunner.run
        original_invoke = TensorProgramRunner._invoke
        active = {}

        def invoke(operation, inputs):
            fields = dict(active)
            fields.update(stream=torch.cuda.current_stream(inputs[0].device).cuda_stream,
                          capturing=torch.cuda.is_current_stream_capturing())
            emit("invoke_enter", **fields)
            try:
                result = original_invoke(operation, inputs)
            except Exception as error:
                emit("invoke_error", error_type=type(error).__name__,
                     error=str(error), **fields)
                raise
            emit("invoke_return", **fields)
            return result

        def run(self, key, operation, inputs, *, mutable):
            values, mutations = tuple(inputs), tuple(mutable)
            active.clear()
            active.update(runner=id(self), call=self.calls + 1,
                          key_digest=hashlib.sha256(repr(key).encode()).hexdigest())
            fields = dict(active)
            emit("run_enter", key=repr(key), mode=self.mode,
                 entries=len(self.entries), replays=self.replays,
                 inputs=[dict(shape=list(v.shape), stride=list(v.stride()),
                              dtype=str(v.dtype), pointer=v.data_ptr()) for v in values],
                 mutable_pointers=[v.data_ptr() for v in mutations], **fields)
            try:
                result = original_run(self, key, operation, values, mutable=mutations)
                if args.sync_after_program:
                    torch.cuda.synchronize(values[0].device)
            except Exception as error:
                emit("run_error", error_type=type(error).__name__,
                     error=str(error), **fields)
                raise
            emit("run_return", entries=len(self.entries), replays=self.replays,
                 outputs=[dict(shape=list(v.shape), dtype=str(v.dtype),
                               pointer=v.data_ptr()) for v in result], **fields)
            return result

        TensorProgramRunner.run = run
        TensorProgramRunner._invoke = staticmethod(invoke)
        sys.argv = [str(target), *remaining]
        runpy.run_path(str(target), run_name="__main__")


if __name__ == "__main__":
    main()
