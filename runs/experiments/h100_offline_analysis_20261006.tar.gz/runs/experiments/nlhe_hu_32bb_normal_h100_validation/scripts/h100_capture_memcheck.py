"""One bounded asynchronous capture diagnostic, after the verified live benchmark."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import time

ROOT = Path('/workspace/ai-game-learning')
BASE = ROOT / 'runs/experiments/nlhe_hu_32bb_normal_h100_validation'
REPORTS = BASE / 'reports'
STATE = REPORTS / 'capture_memcheck_status.json'
DEADLINE = dt.datetime(2026, 10, 7, 0, 0, tzinfo=dt.timezone.utc).timestamp()
GPU = os.environ['CUDA_VISIBLE_DEVICES']
QUEUE = 165191
STOP = False


def process(pid):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        return fields[0], fields[19]
    except FileNotFoundError:
        return None


def record(**values):
    data = dict(controller_pid=os.getpid(), deadline_utc='2026-10-07T00:00:00Z',
                updated_utc=dt.datetime.now(dt.timezone.utc).isoformat(), **values)
    STATE.write_text(json.dumps(data, indent=2) + '\n')


def owners():
    return subprocess.check_output(['nvidia-smi', '--id=' + GPU,
        '--query-compute-apps=pid,used_memory', '--format=csv,noheader'], text=True).strip()


def stop(signum, frame):
    global STOP
    STOP = True


signal.signal(signal.SIGINT, stop)
signal.signal(signal.SIGTERM, stop)
os.chdir(ROOT)
queue_start = process(QUEUE)
assert queue_start and b'h100_bounded_finish.py' in Path(f'/proc/{QUEUE}/cmdline').read_bytes()
record(status='waiting_for_live_benchmark_controller', wait_pid=QUEUE, wait_start=queue_start[1])
while True:
    current = process(QUEUE)
    if not current or current[1] != queue_start[1] or current[0] == 'Z':
        break
    if STOP or time.time() >= DEADLINE - 300:
        record(status='deferred', reason='Insufficient remaining wall-clock budget')
        sys.exit(0)
    time.sleep(2)
observed = owners()
if observed:
    record(status='deferred', reason='GPU occupied after benchmark controller exit', gpu_owners=observed)
    sys.exit(1)

directory = ROOT / 'runs/experiments/nlhe_hu_32bb_normal_h100_captured_k2_memcheck_8236a61'
directory.mkdir(parents=True, exist_ok=True)
log = directory / 'memcheck.log'
console = directory / 'console.log'
training = BASE / 'scripts/h100_training_benchmark.py'
env = dict(os.environ, TORCHINDUCTOR_MAX_AUTOTUNE_GEMM_BACKENDS='ATEN',
           TORCHINDUCTOR_COMPILE_THREADS='4')
env.pop('CUDA_LAUNCH_BLOCKING', None)
command = ['/usr/local/cuda/bin/compute-sanitizer', '--tool', 'memcheck',
    '--error-exitcode', '86', '--ignore-getprocaddress-notfound', '--log-file', str(log),
    sys.executable, str(training), '--replicas', '2', '--mode', 'normal', '--stage', 'smoke',
    '--program', 'captured', '--learner-pack', '2', '--post-pack', '2', '--warmup', '0',
    '--repeats', '1', '--directory', str(directory)]
identity = dict(source_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    training_sha256=hashlib.sha256(training.read_bytes()).hexdigest(),
    scope='One asynchronous full public captured smoke under Compute Sanitizer. All timing is diagnostic; no speed or intermittent-safety claim.',
    CUDA_LAUNCH_BLOCKING=env.get('CUDA_LAUNCH_BLOCKING'), force_blocking_launches=False)
timed_out = False
with console.open('w') as output:
    child = subprocess.Popen(command, env=env, stdout=output, stderr=subprocess.STDOUT,
                             start_new_session=True)
    record(status='running', child_pid=child.pid, command=command, identity=identity)
    while child.poll() is None:
        if STOP or time.time() >= DEADLINE:
            timed_out = True
            for sig in (signal.SIGTERM, signal.SIGKILL):
                try:
                    os.killpg(child.pid, sig)
                except ProcessLookupError:
                    pass
                if sig == signal.SIGTERM:
                    time.sleep(5)
            break
        time.sleep(2)
    child.wait()
for _ in range(30):
    observed = owners()
    if not observed:
        break
    time.sleep(.2)
status = 'timeboxed' if timed_out else ('complete' if child.returncode == 0 else 'diagnostic_failure')
result = dict(status=status, returncode=child.returncode, identity=identity,
              final_gpu_owners=observed, log=str(log), console=str(console))
(directory / 'diagnostic_result.json').write_text(json.dumps(result, indent=2) + '\n')
if child.returncode or timed_out:
    import shutil
    for scratch in (directory / 'runtime', ROOT / 'configs/experiments' / directory.name):
        if scratch.exists():
            shutil.rmtree(scratch)
record(**result)
assert not observed, 'Owned diagnostic did not release GPU; see status'
(REPORTS / 'capture_memcheck_final_gpu.txt').write_text(subprocess.check_output(
    ['nvidia-smi', '--id=' + GPU], text=True))

# Refresh the offline archive with this last diagnostic; no GPU work follows.
archive = ROOT / 'runs/experiments/h100_offline_analysis_20261006.tar.gz'
temporary = archive.with_name(archive.name + '.tmp')
with tarfile.open(temporary, 'w:gz') as output:
    for path in (ROOT / 'docs/audit').glob('*h100*20261006.md'):
        output.add(path, arcname=str(path.relative_to(ROOT)))
    for directory in (ROOT / 'runs/experiments').glob('*h100*'):
        if not directory.is_dir():
            continue
        for path in directory.rglob('*'):
            if path.is_file() and 'runtime' not in path.relative_to(directory).parts and path.suffix in ('.json', '.jsonl', '.log', '.csv', '.txt', '.py', '.md', '.diff'):
                output.add(path, arcname=str(path.relative_to(ROOT)))
    for path in (ROOT / 'configs/experiments').rglob('*.yaml'):
        if 'h100' in str(path):
            output.add(path, arcname=str(path.relative_to(ROOT)))
    for path in (ROOT / 'tools/h100-gpm-monitor.py', ROOT / 'pbg/h100_pilot.py'):
        output.add(path, arcname=str(path.relative_to(ROOT)))
temporary.replace(archive)
record(**result, offline_archive=str(archive), archive_bytes=archive.stat().st_size)
